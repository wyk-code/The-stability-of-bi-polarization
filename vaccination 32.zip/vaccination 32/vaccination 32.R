library(readxl)
new_data <- read_excel("edge_node.xlsx")

source_opinion<-new_data$source_opinion
target_opinion<-new_data$target_opinion

zhengzheng<-0
zhengling<-0
zhengfu<-0
lingzheng<-0
lingling<-0
lingfu<-0
fuzheng<-0
fuling<-0
fufu<-0

for(h in 1:length(source_opinion)){
  if(source_opinion[h]=='1'&&target_opinion[h]=='1')
    zhengzheng<-zhengzheng+1
  if(source_opinion[h]=='1'&&target_opinion[h]=='0')
    zhengling<-zhengling+1
  if(source_opinion[h]=='1'&&target_opinion[h]=='-1')
    zhengfu<-zhengfu+1
  if(source_opinion[h]=='0'&&target_opinion[h]=='1')
    lingzheng<-lingzheng+1
  if(source_opinion[h]=='0'&&target_opinion[h]=='0')
    lingling<-lingling+1
  if(source_opinion[h]=='0'&&target_opinion[h]=='-1')
    lingfu<-lingfu+1
  if(source_opinion[h]=='-1'&&target_opinion[h]=='1')
    fuzheng<-fuzheng+1
  if(source_opinion[h]=='-1'&&target_opinion[h]=='0')
    fuling<-fuling+1
  if(source_opinion[h]=='-1'&&target_opinion[h]=='-1')
    fufu<-fufu+1
}

(zhengling+lingzheng+lingfu+fuling)/length(source_opinion)
K0<-0.5509767
K1<-0.9456602
K2<-25.03159
zheng<-20009
ling<-154
fu<-34188
zheng<-zheng/54351
ling<-ling/54351
fu<-fu/54351
