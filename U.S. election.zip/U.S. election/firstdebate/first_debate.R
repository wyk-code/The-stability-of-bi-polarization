library(readxl)
new_data <- read_excel("opinion_network.xlsx")

source_opinion<-new_data$source_opinion
target_opinion<-new_data$target_opinion

zhengzheng<-0
zhengling<-0
zhengfu<-0
lingzheng<-0
lingling<-0
lingfu<-0
fuzheng<-0
fuling<-0
fufu<-0

for(h in 1:length(source_opinion)){
  if(source_opinion[h]=='1'&&target_opinion[h]=='1')
    zhengzheng<-zhengzheng+1
  if(source_opinion[h]=='1'&&target_opinion[h]=='0')
    zhengling<-zhengling+1
  if(source_opinion[h]=='1'&&target_opinion[h]=='-1')
    zhengfu<-zhengfu+1
  if(source_opinion[h]=='0'&&target_opinion[h]=='1')
    lingzheng<-lingzheng+1
  if(source_opinion[h]=='0'&&target_opinion[h]=='0')
    lingling<-lingling+1
  if(source_opinion[h]=='0'&&target_opinion[h]=='-1')
    lingfu<-lingfu+1
  if(source_opinion[h]=='-1'&&target_opinion[h]=='1')
    fuzheng<-fuzheng+1
  if(source_opinion[h]=='-1'&&target_opinion[h]=='0')
    fuling<-fuling+1
  if(source_opinion[h]=='-1'&&target_opinion[h]=='-1')
    fufu<-fufu+1
}
zheng<-10363
ling<-1019
fu<-12537
zheng<-zheng/23919
ling<-ling/23919
fu<-fu/23919

K0<-0.5209184
K1<-6.3744
K2<-25.61479



((zheng*ling+ling*zheng+ling*fu+fu*ling)/K1)/(zheng*(zheng/K0+ling/K1+fu/K2)+ling*(zheng/K1+ling/K0+fu/K1)+fu*(zheng/K2+ling/K1+fu/K0))
# [1] 0.01285041
(zhengling+lingzheng+lingfu+fuling)/length(source_opinion)
# [1] 0.01044095
