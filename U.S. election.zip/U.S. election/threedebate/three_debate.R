library(readxl)
new_data <- read_excel("opinion_network.xlsx")

source_opinion<-new_data$source_opinion
target_opinion<-new_data$target_opinion

zhengzheng<-0
zhengling<-0
zhengfu<-0
lingzheng<-0
lingling<-0
lingfu<-0
fuzheng<-0
fuling<-0
fufu<-0

for(h in 1:length(source_opinion)){
  if(source_opinion[h]=='1'&&target_opinion[h]=='1')
    zhengzheng<-zhengzheng+1
  if(source_opinion[h]=='1'&&target_opinion[h]=='0')
    zhengling<-zhengling+1
  if(source_opinion[h]=='1'&&target_opinion[h]=='-1')
    zhengfu<-zhengfu+1
  if(source_opinion[h]=='0'&&target_opinion[h]=='1')
    lingzheng<-lingzheng+1
  if(source_opinion[h]=='0'&&target_opinion[h]=='0')
    lingling<-lingling+1
  if(source_opinion[h]=='0'&&target_opinion[h]=='-1')
    lingfu<-lingfu+1
  if(source_opinion[h]=='-1'&&target_opinion[h]=='1')
    fuzheng<-fuzheng+1
  if(source_opinion[h]=='-1'&&target_opinion[h]=='0')
    fuling<-fuling+1
  if(source_opinion[h]=='-1'&&target_opinion[h]=='-1')
    fufu<-fufu+1
}
zheng<-14756
ling<-109
fu<-10473
zheng<-zheng/25338
ling<-ling/25338
fu<-fu/25338
K0<-((zheng*zheng+ling*ling+fu*fu)/(zhengzheng+lingling+fufu))*(zhengzheng+zhengling+zhengfu+lingzheng+lingling+lingfu+fuzheng+fuling+fufu)
# [1] 0.5204417
K1<-((zheng*ling+ling*zheng+ling*fu+fu*ling)/(zhengling+lingzheng+lingfu+fuling))*(zhengzheng+zhengling+zhengfu+lingzheng+lingling+lingfu+fuzheng+fuling+fufu)
# [1] 6.887962
K2<-((zheng*fu+fu*zheng)/(zhengfu+fuzheng))*(zhengzheng+zhengling+zhengfu+lingzheng+lingling+lingfu+fuzheng+fuling+fufu)
# [1] 25.61313

a<-matrix(c(zhengzheng,zhengling,zhengfu,lingzheng,lingling,lingfu,fuzheng,fuling,fufu)/length(source_opinion),3,3,byrow = T)
b<-matrix(c(zheng*zheng/K0,zheng*ling/K1,zheng*fu/K2,ling*zheng/K1,ling*ling/K0,ling*fu/K1,fu*zheng/K2,fu*ling/K1,fu*fu/K0),3,3,byrow = T)

K00<-(ling*ling/lingling)*(zhengzheng+zhengling+zhengfu+lingzheng+lingling+lingfu+fuzheng+fuling+fufu)
# [1] 0.006950275
K0<-((zheng*zheng+fu*fu)/(zhengzheng+fufu))*(zhengzheng+zhengling+zhengfu+lingzheng+lingling+lingfu+fuzheng+fuling+fufu)
# [1] 0.5218407
K11<-((ling*zheng+ling*fu)/(lingzheng+lingfu))*(zhengzheng+zhengling+zhengfu+lingzheng+lingling+lingfu+fuzheng+fuling+fufu)
# [1] 6.986361
K1<-((zheng*ling+fu*ling)/(zhengling+fuling))*(zhengzheng+zhengling+zhengfu+lingzheng+lingling+lingfu+fuzheng+fuling+fufu)
# [1] 6.792296
K2<-((zheng*fu+fu*zheng)/(zhengfu+fuzheng))*(zhengzheng+zhengling+zhengfu+lingzheng+lingling+lingfu+fuzheng+fuling+fufu)
# [1] 25.61313
a<-matrix(c(zhengzheng,zhengling,zhengfu,lingzheng,lingling,lingfu,fuzheng,fuling,fufu)/length(source_opinion),3,3,byrow = T)
b<-matrix(c(zheng*zheng/K0,zheng*ling/K1,zheng*fu/K2,ling*zheng/K11,ling*ling/K00,ling*fu/K11,fu*zheng/K2,fu*ling/K1,fu*fu/K0),3,3,byrow = T)
