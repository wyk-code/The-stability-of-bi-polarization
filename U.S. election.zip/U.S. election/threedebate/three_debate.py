# -*- coding: utf-8 -*-
"""
Created on Wed Mar 13 22:06:47 2024

@author: wyk
"""

import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
from matplotlib.backends.backend_pdf import PdfPages
 
data_link_three_debate_fraction_data=[[0.654474749,0.0001751712,0.0077776026],
                                 [0.000280274,0.0026626027,0.0003328253],
                                 [0.011018270,0.0004554452,0.3228230595]]


data_link_three_debate_fraction_model=[[0.6524802939,3.658384e-04,0.0094000000],
                                       [0.0003658384,3.071498e-05,0.0002591616],
                                       [0.0094000000,2.591616e-04,0.3274389911]]

plt.figure(figsize=(25,6))
plt.subplot(1,3,1)
ax=sns.heatmap(data=data_link_three_debate_fraction_data,
            cmap='Greens',
            annot=True,
            linewidths=3,
            linecolor='white',
            fmt="0.5f",
            xticklabels=['+','⊙','—'],
            yticklabels=['+','⊙','—'],
            annot_kws={"fontsize":18},
            square=True,
            )
plt.title('Data',fontsize=23)
cbar = ax.collections[0].colorbar
cbar.ax.tick_params(labelsize=18)
plt.xticks(fontsize=22)
plt.yticks(fontsize=22)



plt.subplot(1,3,2)
ax=sns.heatmap(data=data_link_three_debate_fraction_model,
            cmap='Greens',
            annot=True,
            linewidths=3,
            linecolor='white',
            fmt="0.5f",
            xticklabels=['+','⊙','—'],
            yticklabels=['+','⊙','—'],
            annot_kws={"fontsize":18},
            square=True,
            )
plt.title('Data fitting with model',fontsize=23)
cbar = ax.collections[0].colorbar
cbar.ax.tick_params(labelsize=18)
plt.xticks(fontsize=22)
plt.yticks(fontsize=22)
plt.subplots_adjust(wspace=0.25)

plt.subplot(1,3,3)
x=['First debate','Second debate','Third debate']
y_theory=[0.01388,0.00745,0.00125]
y_data=[0.01044,0.00649,0.00125]
plt.plot(x, y_data, color='#77AC30',linewidth=3,linestyle='-',marker='s',markersize=12,label='Data')
plt.plot(x, y_theory, color='#EAAF64',linewidth=3,linestyle='--',marker='o',markersize=12,label='Theory')
plt.grid()
plt.legend()
plt.ylabel('Active links', fontsize=23)
plt.legend(fontsize=18)
plt.tick_params(axis='x', labelsize=18)
plt.tick_params(axis='y', labelsize=18)

